#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>

void *ring_func(void *p)
{
  int token;
  // Receive from the lower process and send to the higher process. Take care
  // of the special case when you are the first process to prevent deadlock.

  int world_rank;
  MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
  int world_size;
  MPI_Comm_size(MPI_COMM_WORLD, &world_size);

world_size = world_size - 2;

  if (world_rank != 0) {
    MPI_Recv(&token, 1, MPI_INT, world_rank - 1, 0, MPI_COMM_WORLD,
             MPI_STATUS_IGNORE);
    printf("Process %d received token %d from process %d\n", world_rank, token,
           world_rank - 1);
  } else {
// Set the token's value if you are process
 token = -1;
  }
MPI_Send(&token, 1, MPI_INT, (world_rank + 1) % world_size, 0,
           MPI_COMM_WORLD);

 if (world_rank == 0) {
//    sleep(20);
    MPI_Recv(&token, 1, MPI_INT, world_size - 1, 0, MPI_COMM_WORLD,
             MPI_STATUS_IGNORE);
    printf("Process %d received token %d from process %d\n", world_rank, token,
           world_size - 1);
  }

pthread_exit(NULL);
}

int main(int argc, char** argv) {
  // Initialize the MPI threaded environment

  int provided;
  MPI_Init_thread(&argc, &argv, MPI_THREAD_MULTIPLE , &provided);
 if (provided != MPI_THREAD_MULTIPLE)
 {
    printf("Error: the MPI library doesn't provide the required thread level\n");
       MPI_Abort(MPI_COMM_WORLD, 0);
       } else {
	printf("ok\n");
}

 int world_rank;
  MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
  int world_size;
  MPI_Comm_size(MPI_COMM_WORLD, &world_size);

if (world_rank < 2) {

  pthread_t ring ;
  pthread_create (&ring, NULL, ring_func, NULL) ;
  pthread_join(ring,NULL);
}
  MPI_Barrier(MPI_COMM_WORLD);
  MPI_Finalize();
}

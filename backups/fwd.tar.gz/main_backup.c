#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <assert.h>
#include <mpi.h>
#include <fcntl.h>
#include <math.h>
#include <unistd.h>

#include "fwd_list.h"

#define READ 0
#define WRITE 1
#define OPEN 3
#define CLOSE 4

#define MAXIMUM_REQUEST_SIZE (64 * 1024 * 1024)

#define TAG_REQUEST 10000
#define TAG_BUFFER 20000
#define TAG_ACK 90000

#define TOTAL_SIZE_PER_PROCESS (1 * 1024 * 1024 * 1024)
#define REQUEST_SIZE (1 * 1024)

#define CONTIGUOUS 0
#define STRIDED 1

const int MAX_STRING = 100;
const int IO_FORWARDING_SEVERS = 8;

const int EMPTY = 0;

struct request {
	char file_handle[255];
	int operation;
	int offset;
	int size;
};

// Structure to keep track of the requests in the forwarding layer
struct forwarding_request {
	int rank;

	char *file_handle;
	int operation;
	int offset;
	int size;
	char *buffer;

	struct fwd_list_head list; 
};

int world_size, world_rank;

void *server_listen(void *p) {
	int i, ack = 1;

	char *buffer = malloc(MAXIMUM_REQUEST_SIZE * sizeof(char));

	// Decalres and initializa the forwarding the request queue
	struct forwarding_request request_queue;
	init_fwd_list_head(&request_queue.list);

	#ifdef DEBUG
	struct forwarding_request *tmp;
	#endif

	MPI_Datatype request_datatype;
	int block_lengths[4] = {255, 1, 1, 1};
	MPI_Datatype type[4] = {MPI_CHAR, MPI_INT, MPI_INT, MPI_INT};
	MPI_Aint displacement[4];

	MPI_Request request;

	struct request req;

	// Compute displacements of structure components
	MPI_Get_address(&req, displacement);
	MPI_Get_address(&req.operation, displacement + 1);
	MPI_Get_address(&req.offset, displacement + 2);
	MPI_Get_address(&req.size, displacement + 3);
	
	MPI_Aint base = displacement[0];

	for (i = 0; i < 4; i++) {
		displacement[i] = MPI_Aint_diff(displacement[i], base); 
	}

	MPI_Type_create_struct(4, block_lengths, displacement, type, &request_datatype); 
	MPI_Type_commit(&request_datatype);

	MPI_Status status;

	printf("LISTENING...\n");

	int shutdown = 0;
	unsigned long int total_requests = 0;

	// Listen for incoming requests
	while (1) {
		// Receive the message
		// MPI_Recv(greeting, MAX_STRING, MPI_CHAR, MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
		MPI_Recv(&req, 1, request_datatype, MPI_ANY_SOURCE, TAG_REQUEST, MPI_COMM_WORLD, &status);

		// Keep track of the number of requests
		total_requests++;

		MPI_Get_count(&status, request_datatype, &i);

		#ifdef DEBUG
		// Discover the rank that sent us the message
		printf("Received message from %d with length %d\n", status.MPI_SOURCE, i);
		#endif

		// Empty message means we are requests to shutdown
		if (i == 0) {
			#ifdef DEBUG
			printf("Process %d has finished\n", status.MPI_SOURCE);
			#endif

			shutdown++;
		}

		// If all the nodes requested a shutdown, we can proceed
		if (shutdown == (world_size - IO_FORWARDING_SEVERS) / IO_FORWARDING_SEVERS) {
			#ifdef DEBUG
			printf("SHUTDOWN\n");
			#endif

			break;
		}

		if (i == 0) {
			// We need to keep listening for SHUTDOWN requests
			continue;
		}

		#ifdef DEBUG
		printf("[  ][%d] %d %s %d %d\n", status.MPI_SOURCE, req.operation, req.file_handle, req.offset, req.size);
		#endif

		// Create the request
		struct forwarding_request *r = (struct forwarding_request *) malloc(sizeof(struct forwarding_request));

		r->operation = req.operation;
		r->rank = status.MPI_SOURCE;
		r->file_handle = req.file_handle;
		r->offset = req.offset;
		r->size = req.size;

		#ifdef DEBUG
		printf("OPERATION: %d\n", r->operation);
		#endif

		// Process the request
		if (r->operation == READ) {
			// Allocate the buffer
			r->buffer = malloc(r->size * sizeof(char));

			// TODO: open the fh before and keep reference count before closing it! For these tests we are going to to it here!
			int fh = open(r->file_handle, O_RDWR, 0666);
			
			// Seek the offset
			if (lseek(fh, r->offset, SEEK_SET) == -1) {
				// TODO: seek failed
				return 0;
			}

			// Read the file
			int rc = read(fh, r->buffer, r->size);
			
			if (rc == -1) {
				// TODO: seek failed
				return 0;
			}

			// Close the file handle
			close(fh);

			MPI_Send(r->buffer, r->size, MPI_CHAR, r->rank, TAG_BUFFER, MPI_COMM_WORLD); 

			// Include the request into the queue
			fwd_list_add_tail(&(r->list), &(request_queue.list));
		} 

		if (r->operation == WRITE) {
			// Make sure the buffer can store the message
			r->buffer = malloc(r->size * sizeof(char));

			#ifdef DEBUG
			printf("waiting to receive the buffer...\n");
			#endif

			MPI_Irecv(r->buffer, r->size, MPI_CHAR, r->rank, TAG_BUFFER, MPI_COMM_WORLD, &request); 

			// Send ACK to receive the buffer
			MPI_Send(&ack, 1, MPI_INT, r->rank, TAG_ACK, MPI_COMM_WORLD); 

			// Wait until we receive the buffer
			MPI_Wait(&request, &status);

			// TODO: open the fh before and keep reference count before closing it! For these tests we are going to to it here!
			int fh = open(r->file_handle, O_CREAT | O_RDWR, 0666);
			
			// Seek the offset
			if (lseek(fh, r->offset, SEEK_SET) == -1) {
				// TODO: seek failed
				return 0;
			}

			// Write the file
			int rc = write(fh, r->buffer, r->size);
            
            if (rc == -1) {
            	// TODO: write failed
            	return 0;
            }

			// Close the file handle
			close(fh);

			int size = 0;

			// Get the size of the received message
			MPI_Get_count(&status, MPI_CHAR, &size);

			// Make sure we received all the buffer
			assert(r->size == size);

			// Include the request into the queue
			fwd_list_add_tail(&(r->list), &(request_queue.list));
		}
	}

	#ifdef DEBUG
	// Print the items on the list to make sure we have all the requests
	fwd_list_for_each_entry(tmp, &request_queue.list, list) {
		printf("%s request from rank %d with offset %d and size %d\n", (tmp->operation == READ ? "READ" : "WRITE"), tmp->rank, tmp->offset, tmp->size);
	}
	#endif

	printf("TOTAL REQUESTS: %ld\n", total_requests);

	// Free the buffer
	free(buffer);

	pthread_exit(NULL);
}

int get_forwarding_server() {
	// We need to split the clients between the forwarding servers
	return (world_rank - IO_FORWARDING_SEVERS) / ((world_size - IO_FORWARDING_SEVERS) / IO_FORWARDING_SEVERS);
}

int main(int argc, char *argv[]) {
	int i, n, my_forwarding_server, ack, spatiality;
	int provided;

	MPI_Status status;

	char *buffer = malloc(MAXIMUM_REQUEST_SIZE * sizeof(char));

	if (buffer == NULL) {
		printf("ERROR: Unable to allocate the maximum memory size of %d bytes for requests \n", MAXIMUM_REQUEST_SIZE);

		MPI_Abort(MPI_COMM_WORLD, 0);
	}

	/* Start up MPI */
	MPI_Init_thread(&argc, &argv, MPI_THREAD_MULTIPLE , &provided);
	
	if (provided != MPI_THREAD_MULTIPLE) {
		printf("ERROR: the MPI library doesn't provide the required thread level\n");

		MPI_Abort(MPI_COMM_WORLD, 0);
	}

	/* Get the number of processes */
	MPI_Comm_size(MPI_COMM_WORLD, &world_size); 

	/* Get my rank among all the processes */
	MPI_Comm_rank(MPI_COMM_WORLD, &world_rank); 

	// Get the name of the processor
	char processor_name[MPI_MAX_PROCESSOR_NAME];
	int name_len;
	MPI_Get_processor_name(processor_name, &name_len);

	#ifdef DEBUG
	// Print off a hello world message
	printf("Hello world from processor %s, rank %d out of %d processors\n", processor_name, world_rank, world_size);
	#endif

	int is_forwarding = 0;

	// We need to split the processes into forwarding servers and the simulated clients
	if (world_rank < IO_FORWARDING_SEVERS) {
		is_forwarding = 1;
	}

	// Communicator for the processes that are a part of the forwarding server
	MPI_Comm forwarding_comm;
	MPI_Comm_split(MPI_COMM_WORLD, is_forwarding, world_rank, &forwarding_comm);

	int forwarding_rank, forwarding_size;
	MPI_Comm_rank(forwarding_comm, &forwarding_rank);
	MPI_Comm_size(forwarding_comm, &forwarding_size);

	// Communicator for the processes that are forwarding clients
	MPI_Comm clients_comm;
	MPI_Comm_split(MPI_COMM_WORLD, !is_forwarding, world_rank, &clients_comm);

	int client_rank, client_size;
	MPI_Comm_rank(clients_comm, &client_rank);
	MPI_Comm_size(clients_comm, &client_size);

	printf("RANK %d\tROLE: %d\n", world_rank, is_forwarding);

	MPI_Barrier(MPI_COMM_WORLD);

	MPI_Datatype request_datatype;
	int block_lengths[4] = {255, 1, 1, 1};
	MPI_Datatype type[4] = {MPI_CHAR, MPI_INT, MPI_INT, MPI_INT};
	MPI_Aint displacement[4];

	struct request req;

	// Compute displacements of structure components
	MPI_Get_address(&req, displacement);
	MPI_Get_address(&req.operation, displacement + 1);
	MPI_Get_address(&req.offset, displacement + 2);
	MPI_Get_address(&req.size, displacement + 3);
	
	MPI_Aint base = displacement[0];

	for (i = 0; i < 4; i++) {
		displacement[i] = MPI_Aint_diff(displacement[i], base); 
	}

	MPI_Type_create_struct(4, block_lengths, displacement, type, &request_datatype); 
	MPI_Type_commit(&request_datatype);

	if (is_forwarding) {
		printf("WORLD RANK/SIZE: %d/%d \t ROW RANK/SIZE: %d/%d\n",world_rank, world_size, forwarding_rank, forwarding_size);

		pthread_t listen;
		pthread_create(&listen, NULL, server_listen, NULL);
		pthread_join(listen, NULL);

		// We need this barrier in the end or when we have finished, so that we can shutdown cleanly
		//MPI_Barrier(forwarding_comm);
	} else {
		struct request *r;

		// Define the forwarding server we should interact with
		my_forwarding_server = get_forwarding_server();

		#ifdef DEBUG
		printf("RANK %d\tFORWARDER SERVER: %d\n", world_rank, my_forwarding_server);

		printf("Sending message from process %d of %d!\n", world_rank, world_size);
		#endif

		/*
		 * WRITE ------------------------------------------------------------------------------------
		 * Issue WRITE requests to the forwarding layer
		 * -----------------------------------------------------------------------------------------
		 */

		n = TOTAL_SIZE_PER_PROCESS / REQUEST_SIZE;
		spatiality = CONTIGUOUS;

		// Fill the buffer with fake data to be written
		for (int i = 0; i < REQUEST_SIZE; i++) {
			buffer[i] = '0' + world_rank;
		}

		printf("%d WRITE requests with CONTIGUOUS access\n", n);

		for (i = 0; i < n; i++) {
			// Create the request
			r = (struct request *) malloc(sizeof(struct request));

			r->operation = WRITE;
			strcpy(r->file_handle, "my-file-write.txt");

			// (world_rank * 1 * 1024) + (i * 1024);

			if (spatiality == CONTIGUOUS) {
				// Offset computation is based on MPI-IO Test implementation
				r->offset = (floor(i / n) * ((REQUEST_SIZE * n) * client_size)) + ((REQUEST_SIZE * n) * client_rank) + (i * REQUEST_SIZE);
			} else {
				// Offset computation is based on MPI-IO Test implementation
				r->offset = i * (client_size * REQUEST_SIZE) + (client_rank * REQUEST_SIZE);
			}
			
			r->size = REQUEST_SIZE;

			#ifdef DEBUG
			printf("[OP][%d] %d %s %d %d\n", world_rank, r->operation, r->file_handle, r->offset, r->size);
			#endif

			// Issue the fake WRITE operation, that should wait for it to complete
			MPI_Send(r, 1, request_datatype, my_forwarding_server, TAG_REQUEST, MPI_COMM_WORLD); 

			#ifdef DEBUG
			printf("waiting for the answer to come...\n");
			#endif

			// We need to wait for the ACK so that the server is ready to receive our buffer
			MPI_Recv(&ack, 1, MPI_INT, my_forwarding_server, TAG_ACK, MPI_COMM_WORLD, &status);

			#ifdef DEBUG
			printf("ACK received, sending buffer...\n");
			#endif

			int send_status;

			// We need to wait for the WRITE request to return before issuing another request
			send_status = MPI_Send(buffer, r->size, MPI_CHAR, my_forwarding_server, TAG_BUFFER, MPI_COMM_WORLD);

			assert(send_status == MPI_SUCCESS);

			#ifdef DEBUG
			printf("sent WRITE data to %d with length %d\n", my_forwarding_server, r->size);
			#endif
		}

		MPI_Barrier(clients_comm);

		/*
		 * READ ------------------------------------------------------------------------------------
		 * Issue READ requests to the forwarding layer
		 * -----------------------------------------------------------------------------------------
		 */
		for (i = 0; i < 10; i++) {
			// Create the request
			r = (struct request *) malloc(sizeof(struct request));

			r->operation = READ;
			strcpy(r->file_handle, "my-file.txt");
			r->offset = i * 1024;
			r->size = 1024;

			// Issue the fake READ operation, that should wait for it to complete
			MPI_Send(r, 1, request_datatype, my_forwarding_server, TAG_REQUEST, MPI_COMM_WORLD); 

			#ifdef DEBUG
			printf("waiting for the answer to come...\n");
			#endif

			// We need to wait for the READ request to return before issuing another request
			MPI_Recv(buffer, r->size, MPI_CHAR, my_forwarding_server, TAG_BUFFER, MPI_COMM_WORLD, &status);

			int size = 0;

			// Get the size of the received message
			MPI_Get_count(&status, MPI_CHAR, &size);

			// Make sure we received all the buffer
			assert(r->size == size);

			#ifdef DEBUG
			// Discover the rank that sent us the message
			printf("received READ data from %d with length %d\n", status.MPI_SOURCE, size);
			#endif
		}

		// Free the request
		free(r);

		/*
		 * SHUTDOWN---------------------------------------------------------------------------------
		 * Issue SHUTDOWN requests to the forwarding layer to finish the experiment
		 * -----------------------------------------------------------------------------------------
		 */

		MPI_Barrier(clients_comm);

		printf("rank %d is sending SHUTDOWN signal\n", world_rank);

		// Send shutdown message
		MPI_Send(buffer, EMPTY, MPI_CHAR, my_forwarding_server, TAG_REQUEST, MPI_COMM_WORLD);
	}

	MPI_Barrier(MPI_COMM_WORLD);

	// Free the communicator used in the forwarding server
	MPI_Comm_free(&forwarding_comm);

	// Free the communicator used by the clients
	MPI_Comm_free(&clients_comm);

	// Free the buffer
	free(buffer);

	/* Shut down MPI */
	MPI_Finalize(); 

	return 0;
}

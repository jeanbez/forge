#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <assert.h>
#include <mpi.h>
#include <fcntl.h>
#include <math.h>
#include <unistd.h>
#include <agios.h>
#include <time.h>

#include "jsmn.h"
#include "uthash.h"

#include "main.h"

const int MAX_STRING = 100;
const int EMPTY = 0;

int simulation_forwarders = 0;

struct request {
	char file_handle[255];
	int operation;
	unsigned long offset;
	unsigned long size;
};

// Structure to keep track of the requests in the forwarding layer
struct forwarding_request {
	unsigned long id;

	int rank;

	char *file_handle;
	int operation;
	unsigned long offset;
	unsigned long size;
	char *buffer;

	UT_hash_handle hh;
};

// Declares the hash to hold the requests and initialize it to NULL (mandatory to initialize to NULL)
struct forwarding_request *requests = NULL;

int world_size, world_rank;

// AGIOS client structure with pointers to callbacks
struct client agios_client;

// TODO: we may need a lock here or replace this identifier by the ID of the request
unsigned long generate_identifier() {
	// Calculates the hash of this request
	struct timespec ts;

	clock_gettime(CLOCK_MONOTONIC, &ts);
	unsigned long id = ts.tv_sec * 1000000000L + ts.tv_nsec;

	return id;
}

// Controle the shutdown signal
int shutdown = 0;
pthread_mutex_t shutdown_lock;

pthread_mutex_t requests_lock;

void callback(unsigned long long int id) {
	int ack = 1;
	struct forwarding_request *r;

	#ifdef DEBUG
	// Discover the rank that sent us the message
	pthread_mutex_lock(&requests_lock);
	printf("Pending requests: %llu\n", HASH_COUNT(requests));
	pthread_mutex_unlock(&requests_lock);
	
	printf("Request ID: %llu\n", id);
	#endif

	// Get the request from the hash
	pthread_mutex_lock(&requests_lock);
    HASH_FIND_INT(requests, &id, r);
    pthread_mutex_unlock(&requests_lock);

    if (r == NULL) {
    	MPI_Abort(MPI_COMM_WORLD, ERROR_INVALID_REQUEST_ID);

    	return;
    }

    #ifdef DEBUG
	printf("[XX][%d] %d %s %ld %ld\n", 0, r->operation, r->file_handle, r->offset, r->size);
	#endif

	// Issue the request to the filesystem
	if (r->operation == WRITE) {
		// TODO: open the fh before and keep reference count before closing it! For these tests we are going to to it here!
		int fh = open(r->file_handle, O_CREAT | O_RDWR, 0666);
		
		// Seek the offset
		if (lseek(fh, r->offset, SEEK_SET) == -1) {
			MPI_Abort(MPI_COMM_WORLD, ERROR_SEEK_FAILED);
		}

		// Write the file
		int rc = write(fh, r->buffer, r->size);
		
		if (rc == -1) {
			MPI_Abort(MPI_COMM_WORLD, ERROR_WRITE_FAILED);
		}

		// Close the file handle
		close(fh);
		
		// Release the AGIOS request
		// agios_release_request(r->file_handle, r->operation, r->size, r->offset, 0, r->size); // 0 is a sub-request
		
		// Send ACK to the client to indicate the operation was completed
		MPI_Send(&ack, 1, MPI_INT, r->rank, TAG_ACK, MPI_COMM_WORLD); 
	}

	if (r->operation == READ) {
		// TODO: open the fh before and keep reference count before closing it! For these tests we are going to to it here!
		int fh = open(r->file_handle, O_RDONLY, 0666);
		
		// Seek the offset
		if (lseek(fh, r->offset, SEEK_SET) == -1) {
			MPI_Abort(MPI_COMM_WORLD, ERROR_SEEK_FAILED);
		}

		// Read the file
		int rc = read(fh, r->buffer, r->size);
		
		if (rc == -1) {
			MPI_Abort(MPI_COMM_WORLD, ERROR_READ_FAILED);
		}

		// Close the file handle
		close(fh);

		MPI_Send(r->buffer, r->size, MPI_CHAR, r->rank, TAG_BUFFER, MPI_COMM_WORLD); 
	}

	// Remove the request from the hash
	pthread_mutex_lock(&requests_lock);
    HASH_DEL(requests, r);
    pthread_mutex_unlock(&requests_lock);

    free(r);
}

void stop_AGIOS() {
	printf("Stopping AGIOS scheduling library\n");

	agios_exit();
}

void start_AGIOS() {
	agios_client.process_request = (void *) callback;
	// agios_client.process_requests = callback_aggregated;

	// Check if AGIOS was successfully inicialized
	if (agios_init(&agios_client, AGIOS_CONFIGURATION, simulation_forwarders) != 0) {
		printf("Unable to initialize AGIOS scheduling library\n");

		stop_AGIOS();
	}
}

int get_forwarding_server() {
	// We need to split the clients between the forwarding servers
	return (world_rank - simulation_forwarders) / ((world_size - simulation_forwarders) / simulation_forwarders);
}

void *server_listen(void *p) {
	int i, ack = 1;

	MPI_Datatype request_datatype;
	int block_lengths[4] = {255, 1, 1, 1};
	MPI_Datatype type[4] = {MPI_CHAR, MPI_INT, MPI_UNSIGNED_LONG, MPI_UNSIGNED_LONG};
	MPI_Aint displacement[4];

	MPI_Request request;

	struct request req;

	// Compute displacements of structure components
	MPI_Get_address(&req, displacement);
	MPI_Get_address(&req.operation, displacement + 1);
	MPI_Get_address(&req.offset, displacement + 2);
	MPI_Get_address(&req.size, displacement + 3);
	
	MPI_Aint base = displacement[0];

	for (i = 0; i < 4; i++) {
		displacement[i] = MPI_Aint_diff(displacement[i], base); 
	}

	MPI_Type_create_struct(4, block_lengths, displacement, type, &request_datatype); 
	MPI_Type_commit(&request_datatype);

	MPI_Status status;

	#ifdef DEBUG
	printf("LISTENING...\n");
	#endif

	unsigned long int total_requests = 0;

	// Listen for incoming requests
	while (1) {
		// Receive the message
		MPI_Recv(&req, 1, request_datatype, MPI_ANY_SOURCE, TAG_REQUEST, MPI_COMM_WORLD, &status);

		// Keep track of the number of requests
		total_requests++;

		MPI_Get_count(&status, request_datatype, &i);

		#ifdef DEBUG
		// Discover the rank that sent us the message
		printf("Received message from %d with length %d\n", status.MPI_SOURCE, i);
		#endif

		// Empty message means we are requests to shutdown
		if (i == 0) {
			#ifdef DEBUG
			printf("Process %d has finished\n", status.MPI_SOURCE);
			#endif

			pthread_mutex_lock(&shutdown_lock);
			shutdown++;
			pthread_mutex_unlock(&shutdown_lock);
		}

		// If all the nodes requested a shutdown, we can proceed
		if (shutdown == (world_size - simulation_forwarders) / simulation_forwarders) {
			#ifdef DEBUG
			printf("SHUTDOWN\n");
			#endif

			break;
		}

		if (i == 0) {
			// We need to keep listening for SHUTDOWN requests
			continue;
		}

		#ifdef DEBUG
		printf("[  ][%d] %d %s %ld %ld\n", status.MPI_SOURCE, req.operation, req.file_handle, req.offset, req.size);
		#endif

		// Create the request
		struct forwarding_request *r = (struct forwarding_request *) malloc(sizeof(struct forwarding_request));

		r->id = generate_identifier();
		r->operation = req.operation;
		r->rank = status.MPI_SOURCE;
		r->file_handle = req.file_handle;
		r->offset = req.offset;
		r->size = req.size;

		#ifdef DEBUG
		printf("OPERATION: %d\n", r->operation);
		#endif

		// Process the request
		if (r->operation == READ) {
			// Allocate the buffer
			r->buffer = malloc(r->size * sizeof(char));

			// Include the request into the hash list
			pthread_mutex_lock(&requests_lock);
			HASH_ADD_INT(requests, id, r);
			pthread_mutex_unlock(&requests_lock);

			#ifdef DEBUG
			printf("add (handle: %s, operation: %d, offset: %ld, size: %ld, id: %ld)\n", r->file_handle, r->operation, r->offset, r->size, r->id);
			#endif

			// Send the request to AGIOS
			if (agios_add_request(r->file_handle, r->operation, r->offset, r->size, (void *) r->id, &agios_client, 0)) {
				// Failed to sent to AGIOS, we should remove the request from the list
				printf("Failed to send the request to AGIOS\n");

				MPI_Abort(MPI_COMM_WORLD, ERROR_AGIOS_REQUEST);
			}
		} 

		if (r->operation == WRITE) {
			// Make sure the buffer can store the message
			r->buffer = malloc(r->size * sizeof(char));

			#ifdef DEBUG
			printf("waiting to receive the buffer...\n");
			#endif

			MPI_Irecv(r->buffer, r->size, MPI_CHAR, r->rank, TAG_BUFFER, MPI_COMM_WORLD, &request); 

			// Send ACK to receive the buffer
			MPI_Send(&ack, 1, MPI_INT, r->rank, TAG_ACK, MPI_COMM_WORLD); 

			// Wait until we receive the buffer
			MPI_Wait(&request, &status);

			int size = 0;

			// Get the size of the received message
			MPI_Get_count(&status, MPI_CHAR, &size);

			// Make sure we received all the buffer
			assert(r->size == size);

			// Include the request into the hash list
			pthread_mutex_lock(&requests_lock);
			HASH_ADD_INT(requests, id, r);
			pthread_mutex_unlock(&requests_lock);

			#ifdef DEBUG
			printf("add (handle: %s, operation: %d, offset: %ld, size: %ld, id: %ld)\n", r->file_handle, r->operation, r->offset, r->size, r->id);
			#endif

			// Send the request to AGIOS
			if (agios_add_request(r->file_handle, r->operation, r->offset, r->size, (void *) r->id, &agios_client, 0)) {
				// Failed to sent to AGIOS, we should remove the request from the list
				printf("Failed to send the request to AGIOS\n");

				MPI_Abort(MPI_COMM_WORLD, ERROR_AGIOS_REQUEST);
			}
		}
	}

	//#ifdef DEBUG
	printf("TOTAL REQUESTS: %ld\n", total_requests);
	//#endif

	pthread_exit(NULL);

	return NULL;
}

static int jsoneq(const char *json, jsmntok_t *tok, const char *s) {
	if (tok->type == JSMN_STRING && (int) strlen(s) == tok->end - tok->start && strncmp(json + tok->start, s, tok->end - tok->start) == 0) {
		return 0;
	}

	return -1;
}

int main(int argc, char *argv[]) {
	int i, n, my_forwarding_server, ack;
	int provided;

	MPI_Status status;

	char *buffer = malloc(MAXIMUM_REQUEST_SIZE * sizeof(char));

	if (buffer == NULL) {
		printf("ERROR: Unable to allocate the maximum memory size of %d bytes for requests \n", MAXIMUM_REQUEST_SIZE);

		MPI_Abort(MPI_COMM_WORLD, ERROR_MEMORY_ALLOCATION);
	}

	// Start up MPI
	MPI_Init_thread(&argc, &argv, MPI_THREAD_MULTIPLE , &provided);
	
		// Make sure MPI has thread support
	if (provided != MPI_THREAD_MULTIPLE) {
		printf("ERROR: the MPI library doesn't provide the required thread level\n");

		MPI_Abort(MPI_COMM_WORLD, ERROR_UNSUPPORTED);
	}

	// Get the number of processes
	MPI_Comm_size(MPI_COMM_WORLD, &world_size); 

	// Get my rank among all the processes
	MPI_Comm_rank(MPI_COMM_WORLD, &world_rank); 

	// Get the name of the processor
	char processor_name[MPI_MAX_PROCESSOR_NAME];
	int name_len;
	MPI_Get_processor_name(processor_name, &name_len);

	#ifdef DEBUG
	// Print off a hello world message
	printf("Hello world from processor %s, rank %d out of %d processors\n", processor_name, world_rank, world_size);
	#endif

	FILE *json_file;
	char *configuration;
	long bytes;
	 
	// Open the JSON configuration file for reading
	json_file = fopen("simulation.json", "r");
	 
	// Quit if the file does not exist
	if (json_file == NULL) {
	    return 1;
	}
	 
	// Get the number of bytes in the file
	fseek(json_file, 0L, SEEK_END);
	bytes = ftell(json_file);
	 
	// Reset the file position indicator to the beginning of the file
	fseek(json_file, 0L, SEEK_SET);	
	 
	// Allocate sufficient memory for the buffer to hold the text
	configuration = (char*) calloc(bytes, sizeof(char));
	 
	// Check for memory allocation error
	if (configuration == NULL) {
	    return 1;
	}
	 
	// Copy all the text into the configuration
	fread(configuration, sizeof(char), bytes, json_file);

	// Closes the JSON configuration file
	fclose(json_file);

	jsmn_parser parser;
	jsmntok_t tokens[512];

	jsmn_init(&parser);

	int ret = jsmn_parse(&parser, configuration, strlen(configuration), tokens, sizeof(tokens)/sizeof(tokens[0]));
	if (ret < 0) {
		printf("Failed to parse JSON: %d\n", ret);
		
		MPI_Abort(MPI_COMM_WORLD, ERROR_FAILED_TO_PARSE_JSON);
	}

	// Assume the top-level element is an object
	if (ret < 1 || tokens[0].type != JSMN_OBJECT) {
		printf("Object expected\n");
		
		MPI_Abort(MPI_COMM_WORLD, ERROR_INVALID_JSON);
	}

	// Simulation configuration
	char *simulation_file;
	char *simulation_spatiality_name;

	int simulation_spatiality;
	int simulation_request_size;
	int simulation_total_size;

	// Loop over all keys of the root object
	for (i = 1; i < ret; i++) {
		if (jsoneq(configuration, &tokens[i], "forwarders") == 0) {
			simulation_forwarders = atoi(strndup(configuration + tokens[i+1].start, tokens[i+1].end - tokens[i+1].start));

			i++;
		} else if (jsoneq(configuration, &tokens[i], "file") == 0) {
			simulation_file = strndup(configuration + tokens[i+1].start, tokens[i+1].end - tokens[i+1].start);

			i++;
		} else if (jsoneq(configuration, &tokens[i], "spatiality") == 0) {
			simulation_spatiality_name = strndup(configuration + tokens[i+1].start, tokens[i+1].end - tokens[i+1].start);

			i++;

			// Check for supported spatialities
			if (strcmp("contiguous", simulation_spatiality_name) != 0) {
				simulation_spatiality = CONTIGUOUS;
			} else if (strcmp("strided", simulation_spatiality_name) != 0) {
				simulation_spatiality = STRIDED;
			} else {
				// Handle unkown patterns
				MPI_Abort(MPI_COMM_WORLD, ERROR_INVALID_PATTERN);
			}			
		} else if (jsoneq(configuration, &tokens[i], "total_size") == 0) {
			simulation_total_size = atoi(strndup(configuration + tokens[i+1].start, tokens[i+1].end - tokens[i+1].start));

			i++;
		} else if (jsoneq(configuration, &tokens[i], "request_size") == 0) {
			simulation_request_size = atoi(strndup(configuration + tokens[i+1].start, tokens[i+1].end - tokens[i+1].start));

			i++;
		} else {
			printf("Unknown key: %.*s (ignored)\n", tokens[i].end - tokens[i].start, configuration + tokens[i].start);
		}
	}

	// Before proceeding we need to make sure we have the minimum number of processes to simulate
	if (world_size < simulation_forwarders * 2) {
		// In case we do not have at least one client per forwarder we must stop
		MPI_Abort(MPI_COMM_WORLD, ERROR_INVALID_SETUP);
	}

	// Make sure we have a balanced number of clients for each forwading server
	if (world_size % simulation_forwarders) {
		MPI_Abort(MPI_COMM_WORLD, ERROR_INVALID_SETUP);
	}

	int is_forwarding = 0;

	// We need to split the processes into forwarding servers and the simulated clients
	if (world_rank < simulation_forwarders) {
		is_forwarding = 1;
	}

	// Communicator for the processes that are a part of the forwarding server
	MPI_Comm forwarding_comm;
	MPI_Comm_split(MPI_COMM_WORLD, is_forwarding, world_rank, &forwarding_comm);

	int forwarding_rank, forwarding_size;
	MPI_Comm_rank(forwarding_comm, &forwarding_rank);
	MPI_Comm_size(forwarding_comm, &forwarding_size);

	// Communicator for the processes that are forwarding clients
	MPI_Comm clients_comm;
	MPI_Comm_split(MPI_COMM_WORLD, !is_forwarding, world_rank, &clients_comm);

	int client_rank, client_size;
	MPI_Comm_rank(clients_comm, &client_rank);
	MPI_Comm_size(clients_comm, &client_size);

	MPI_File fh;
	MPI_Status s;

	// Snapshot of the simulation configuration
	MPI_File_open(MPI_COMM_WORLD, "simulation.map", MPI_MODE_CREATE|MPI_MODE_WRONLY, MPI_INFO_NULL, &fh);

	char map[16];
	sprintf(map, "rank %d: %s\n", world_rank, (is_forwarding ? "server" : "client"));

	// Write the subarray
	MPI_File_write_ordered(fh, &map, strlen(map), MPI_CHAR, &s);

	// Close the file
	MPI_File_close(&fh);

	MPI_Barrier(MPI_COMM_WORLD);

	MPI_Datatype request_datatype;
	int block_lengths[4] = {255, 1, 1, 1};
	MPI_Datatype type[4] = {MPI_CHAR, MPI_INT, MPI_UNSIGNED_LONG, MPI_UNSIGNED_LONG};
	MPI_Aint displacement[4];

	struct request req;

	// Compute displacements of structure components
	MPI_Get_address(&req, displacement);
	MPI_Get_address(&req.operation, displacement + 1);
	MPI_Get_address(&req.offset, displacement + 2);
	MPI_Get_address(&req.size, displacement + 3);
	
	MPI_Aint base = displacement[0];

	for (i = 0; i < 4; i++) {
		displacement[i] = MPI_Aint_diff(displacement[i], base); 
	}

	MPI_Type_create_struct(4, block_lengths, displacement, type, &request_datatype); 
	MPI_Type_commit(&request_datatype);

	if (is_forwarding) {
		start_AGIOS();

		// Create threads to list for requests
		pthread_t listen[FWD_LISTEN_THREADS];

		for (i = 0; i < FWD_LISTEN_THREADS; i++) {
			pthread_create(&listen[i], NULL, server_listen, NULL);
		}

		for (i = 0; i < FWD_LISTEN_THREADS; i++) {
			printf("to join...\n");
			pthread_join(listen[i], NULL);
			printf("to joined!\n");
		}

		stop_AGIOS();
	} else {
		struct request *r;

		// Define the forwarding server we should interact with
		my_forwarding_server = get_forwarding_server();

		#ifdef DEBUG
		printf("RANK %d\tFORWARDER SERVER: %d\n", world_rank, my_forwarding_server);

		printf("Sending message from process %d of %d!\n", world_rank, world_size);
		#endif

		// Define the size per process
		int simulation_rank_size = ceil(simulation_total_size / client_size);

		n = simulation_rank_size / simulation_request_size;

		// Fill the buffer with fake data to be written
		for (int i = 0; i < simulation_request_size; i++) {
			buffer[i] = '0' + world_rank;
		}

		/*
		 * WRITE ------------------------------------------------------------------------------------
		 * Issue WRITE requests to the forwarding layer
		 * -----------------------------------------------------------------------------------------
		 */

		for (i = 0; i < n; i++) {
			// Create the request
			r = (struct request *) malloc(sizeof(struct request));

			r->operation = WRITE;
			strcpy(r->file_handle, simulation_file);

			if (simulation_spatiality == CONTIGUOUS) {
				// Offset computation is based on MPI-IO Test implementation
				r->offset = (floor(i / n) * ((simulation_request_size * n) * client_size)) + ((simulation_request_size * n) * client_rank) + (i * simulation_request_size);

			} else {
				// Offset computation is based on MPI-IO Test implementation
				r->offset = i * (client_size * simulation_request_size) + (client_rank * simulation_request_size);
			}
			
			r->size = simulation_request_size;

			#ifdef DEBUG
			printf("[OP][%d] %d %s %ld %ld\n", world_rank, r->operation, r->file_handle, r->offset, r->size);
			#endif

			// Issue the fake WRITE operation, that should wait for it to complete
			MPI_Send(r, 1, request_datatype, my_forwarding_server, TAG_REQUEST, MPI_COMM_WORLD); 

			#ifdef DEBUG
			printf("waiting for the answer to come...\n");
			#endif

			// We need to wait for the ACK so that the server is ready to receive our buffer
			MPI_Recv(&ack, 1, MPI_INT, my_forwarding_server, TAG_ACK, MPI_COMM_WORLD, &status);

			#ifdef DEBUG
			printf("ACK received, sending buffer...\n");
			#endif

			int send_status;

			// We need to wait for the WRITE request to return before issuing another request
			send_status = MPI_Send(buffer, r->size, MPI_CHAR, my_forwarding_server, TAG_BUFFER, MPI_COMM_WORLD);

			assert(send_status == MPI_SUCCESS);

			#ifdef DEBUG
			printf("sent WRITE data to %d with length %ld\n", my_forwarding_server, r->size);
			#endif

			// We need to wait for the ACK so that the server has finished to process our request
			MPI_Recv(&ack, 1, MPI_INT, my_forwarding_server, TAG_ACK, MPI_COMM_WORLD, &status);
		}

		MPI_Barrier(clients_comm);

		/*
		 * READ ------------------------------------------------------------------------------------
		 * Issue READ requests to the forwarding layer
		 * -----------------------------------------------------------------------------------------
		 */
		for (i = 0; i < n; i++) {
			// Create the request
			r = (struct request *) malloc(sizeof(struct request));

			r->operation = READ;
			strcpy(r->file_handle, simulation_file);
			
			if (simulation_spatiality == CONTIGUOUS) {
				// Offset computation is based on MPI-IO Test implementation
				r->offset = (floor(i / n) * ((simulation_request_size * n) * client_size)) + ((simulation_request_size * n) * client_rank) + (i * simulation_request_size);
			} else {
				// Offset computation is based on MPI-IO Test implementation
				r->offset = i * (client_size * simulation_request_size) + (client_rank * simulation_request_size);
			}

			r->size = simulation_request_size;

			#ifdef DEBUG
			printf("[OP][%d] %d %s %ld %ld\n", world_rank, r->operation, r->file_handle, r->offset, r->size);
			#endif

			// Issue the fake READ operation, that should wait for it to complete
			MPI_Send(r, 1, request_datatype, my_forwarding_server, TAG_REQUEST, MPI_COMM_WORLD); 

			#ifdef DEBUG
			printf("waiting for the answer to come...\n");
			#endif

			// We need to wait for the READ request to return before issuing another request
			MPI_Recv(buffer, r->size, MPI_CHAR, my_forwarding_server, TAG_BUFFER, MPI_COMM_WORLD, &status);

			int size = 0;

			// Get the size of the received message
			MPI_Get_count(&status, MPI_CHAR, &size);

			// Make sure we received all the buffer
			assert(r->size == size);

			#ifdef DEBUG
			// Discover the rank that sent us the message
			printf("received READ data from %d with length %d\n", status.MPI_SOURCE, size);
			#endif
		}

		// Free the request
		free(r);

		/*
		 * SHUTDOWN---------------------------------------------------------------------------------
		 * Issue SHUTDOWN requests to the forwarding layer to finish the experiment
		 * -----------------------------------------------------------------------------------------
		 */

		MPI_Barrier(clients_comm);

		#ifdef DEBUG
		printf("rank %d is sending SHUTDOWN signal\n", world_rank);
		#endif

		// Send shutdown message
		MPI_Send(buffer, EMPTY, MPI_CHAR, my_forwarding_server, TAG_REQUEST, MPI_COMM_WORLD);
	}

	MPI_Barrier(MPI_COMM_WORLD);

	// Free the communicator used in the forwarding server
	MPI_Comm_free(&forwarding_comm);

	// Free the communicator used by the clients
	MPI_Comm_free(&clients_comm);

	// Free the buffer
	free(buffer);

	/* Shut down MPI */
	MPI_Finalize(); 

	return 0;
}
